class NotAirflowInvalidDAG(Exception):
    pass


class NotAirflowOutsideContext(Exception):
    pass
