# NOTAIRFLOW

A simple python job orchestration tool.

Plan:

Features:

Constraints:
- each task must be self-contained, no params can be passed into a task

